/**
 * @author Derek Windahl, Isaac Freshour, and Steven Proctor
 * Project: AI Project 2
 * Date: 3/1/2019
 * Description: This class holds the relevant information for each queen and counts how many conflicts 
 * 	are present for a queen in a given position. 
 */

public class Queen{
	private int x,y;
	private Board board;

	public Queen(int x, int y, Board board) {
		this.x = x;
		this.y = y;
		this.board = board;
	}

	/*
	 * Inputs:
	 * y = y-axis position of the place where this is checking if there is a conflict or not
	 * 
	 * Output:
	 * conf = number of conflicts found across all diagonals*
	 * 		*conflicts across horizontals and verticals are impossible due to queens being reserved to one per row and column
	 */
	public int getConflicts(int y) {
		int conf = 0;
		for (int i = 1; i < board.getN(); i++) {
			for (Queen q : board.getQueens()) {
				if (q.x == x + i && q.y == y + i)
					conf++;
				if (q.x == x + i && q.y == y - i)
					conf++;
				if (q.x == x - i && q.y == y + i)
					conf++;
				if (q.x == x - i && q.y == y - i)
					conf++;
			}

		}
		return conf;
	}

	public int getY() {
		return y;
	}
	
	public int getX() {
		return x;
	}
	
	public void setY(int y) {
		this.y = y;
	}

	/*
	 * Calls the above getConflicts on the queen's current position
	 */
	public int getConflicts() {
		return getConflicts(y);
	}
}
