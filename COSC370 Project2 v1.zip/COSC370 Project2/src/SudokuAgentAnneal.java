import java.util.Random;

public class SudokuAgentAnneal {
	private int[][] sudokuBoard;
	private boolean[][] readOnly;
	private Random oracle;
	private final int maxTime = 100000, r = 5;
	private boolean verbose;

	public SudokuAgentAnneal(int[][] sudokuBoard, boolean[][] readOnly, int verbose) {
		this.sudokuBoard = sudokuBoard;
		this.readOnly = readOnly;
		oracle = new Random();
		if (verbose == 2)
			this.verbose = false;
		else if (verbose == 1)
			this.verbose = true;
	}

	public int[][] solve() {
		boolean notdone = true;
		int timeout = 0;
		int key = 0;
		while (notdone && timeout < maxTime) {
			timeout++;
			notdone = false;
			for (int i = 0; i < 25; i++) {
				for (int j = 0; j < 25; j++) {
					if (readOnly[i][j] || getConflicts(i, j, sudokuBoard[i][j]) == 0)
						continue;
					notdone = true;

					key = 1;
					double val = getConflicts(i, j, key);
					for (int k = 2; k <= 25; k++) {
						int conf = getConflicts(i, j, k);
						double temp = (conf) + r*oracle.nextDouble()*(maxTime-timeout)/maxTime;
						if (temp < val) {
							key = k;
							val = temp;
						}
					}

					sudokuBoard[i][j] = key;
				}
			}
			// TODO Make a tmpBoard, put all changes onto that, and compare it with sudokuBoard. If tmpBoard is better, replace sudokuBoard 
			// Current setup is a greedy algorithm, not hill climbing. We cannot iterate through and work on each tile individually 
		}
		if (timeout == maxTime) {
			int totalerror=0;
			for (int i = 0; i < 25; i++) {
				for (int j = 0; j < 25; j++) {
					totalerror+=getConflicts(i,j,sudokuBoard[i][j]);
				}
			}
			System.out.println("Time! " + totalerror + " errors found. ");
		}
		return sudokuBoard;
	}

	private int getConflicts(int x, int y, int v) {
		int count = 0;
		int cx = x / 5, cy = y / 5;
		for (int i = 0; i < 25; i++) {
			if (sudokuBoard[x][i] == v && i != y)
				count++;
			if (sudokuBoard[i][y] == v && i != x)
				count++;
		}
		for (int i = 0; i < 5; i++)
			for (int j = 0; j < 5; j++)
				if (sudokuBoard[cx * 5 + i][cy * 5 + j] == v && cx * 5 + i != x && cy * 5 + j != y)
					count++;

		return count;
	}
}
