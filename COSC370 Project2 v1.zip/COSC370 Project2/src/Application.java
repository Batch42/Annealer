import java.io.File;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JFileChooser;

/**
 * @author Derek Windahl, Isaac Freshour, and Steven Proctor
 */
public class Application {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		JFileChooser fileFind = new JFileChooser();
		File sudokuFile;
		int[][] sudokuBoard = new int[25][];
		boolean[][] readOnly = new boolean[25][];
		Random rnd = new Random();

		int choice = 0;
		int verbose = 0;

		System.out.println("Please enter which problem you would like to run. ");
		System.out.println("1 = n-Queens, 2 = Sudoku ");
		System.out.print(">>");
		choice = input.nextInt();
		System.out.println("Would you like verbose output? ");
		System.out.println("1 = Yes, 2 = No");
		System.out.print(">>");
		verbose = input.nextInt();

		if (choice == 1) {
			// Request an "n" value and begin processing 
			System.out.println("Please enter an 'n' value. ");
			System.out.print(">>");
			int nVal = input.nextInt();
			
			Board queenBoard = new Board(nVal);
			queenBoard.anneal();
			
		} else if (choice == 2) {
			// Open a file browser to get the sudoku board .csv file
			//fileFind.showOpenDialog(null);
			//sudokuFile = fileFind.getSelectedFile();
			// TODO Make the file input be done through a cmd line. 
			System.out.println("Please enter your file name. ");
			System.out.print(">>");
			String fileName = input.next();
			URL filePath = Application.class.getResource(fileName);
			
			try (BufferedReader reader = new BufferedReader(new FileReader(new File(filePath.getFile())))) {
				//Build the sudoku board in the program 
				String line = "";
				{
					int i = 0;
					while ((line = reader.readLine()) != null) {
						int j = 0;
						sudokuBoard[i] = new int[25];
						readOnly[i] = new boolean[25];
						for (String item : line.split(",")) {
							int val = Integer.parseInt(item);
							sudokuBoard[i][j] = val == 0 ? rnd.nextInt(25) + 1 : val;
							readOnly[i][j] = val != 0;
							j++;
						}
						i++;
					}
				}
				//Process the sudoku board through hill climbing and then output 
				System.out.println("\nProcessing through Hill Climbing... ");
				int[][] solutionHill = new SudokuAgentHill(sudokuBoard, readOnly, verbose).solve();
				for (int i = 0; i < 25; i++) {
					for (int j = 0; j < 25; j++) {
						System.out.print(solutionHill[i][j] + ", ");
						if (solutionHill[i][j] < 10) {
							System.out.print(" ");
						}
					}
					System.out.println();
				}
				//Process the sudoku board through simulated annealing and then output 
				System.out.println("\nProcessing through Simulated Annealing... ");
				int[][] solutionAnneal = new SudokuAgentAnneal(sudokuBoard, readOnly, verbose).solve();
				for (int i = 0; i < 25; i++) {
					for (int j = 0; j < 25; j++) {
						System.out.print(solutionAnneal[i][j] + ", ");
						if (solutionAnneal[i][j] < 10) {
							System.out.print(" ");
						}
					}
					System.out.println();
				}
			} catch (FileNotFoundException fnfe) {
				System.err.println(fnfe);
			} catch (IOException ioe) {
				System.err.println(ioe);
			}

		} else {
			System.err.println("Invalid input. Please try again. ");
		}
		input.close();

	}// end main
}// end class